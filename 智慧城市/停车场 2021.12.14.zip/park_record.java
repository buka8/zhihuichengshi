package com.example.smartcity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class park_record extends AppCompatActivity {

    private TextView mTime1;
    private TextView mTime2;
    private Button btn;
    private Button btn2;
    private String t1;
    private String t2;


    private List<park_recordBean> data = new ArrayList<>();
    private int isMore = 0;
    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.park_record);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("停哪儿");

        mTime1 = findViewById(R.id.park_record_time1);
        mTime2 = findViewById(R.id.park_record_time2);
        mTime1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timeShow(mTime1);
            }
        });
        mTime2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timeShow(mTime2);
            }
        });


        btn = (Button) findViewById(R.id.park_record_serch);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //页面列表
                mListView = (ListView) findViewById(R.id.park_record_lv);
                t1 = (String) mTime1.getText();
                Log.d("ccc", "show: " + t1);
                show(isMore, "entryTime=" + t1);
                TextView show = (TextView) findViewById(R.id.park_show);
                show.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        isMore++;
                        show(isMore, "entryTime=" + t1);
                    }
                });
            }
        });

        btn2 = (Button) findViewById(R.id.park_record_serch2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //页面列表
                mListView = (ListView) findViewById(R.id.park_record_lv);

                t2 = (String) mTime2.getText();
                show(isMore, "outTime=" + t2);
                TextView show = (TextView) findViewById(R.id.park_show);
                show.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        isMore++;
                        show(isMore, "outTime=" + t2);
                    }
                });
            }
        });


    }

    public void timeShow(TextView v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final LinearLayout layout_alert = (LinearLayout) getLayoutInflater().inflate(R.layout.time, null);
        builder.setView(layout_alert)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        DatePicker datePicker = (DatePicker) layout_alert.findViewById(R.id.time);
                        int y = datePicker.getYear();
                        int m = datePicker.getMonth() + 1;
                        int d = datePicker.getDayOfMonth();
                        v.setText(y + "-" + m + "-" + d);
                    }
                })
                .setNeutralButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .create()
                .show();
    }


    private void show(int isMore, String a) {
        Network network = new Network();

        network.useSendRequestWithOkHttp("http://124.93.196.45:10001/prod-api/api/park/lot/record/list?" + a, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseData = response.body().string();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        data.clear();
                        mListView.setAdapter(null);

                        try {
                            JSONObject jsonObject = new JSONObject(responseData);

                            JSONArray jsonArray = jsonObject.getJSONArray("rows");
                            Log.d("ccc", "run: " + jsonArray.length());
                            if (jsonArray.length() > 0) {
                                for (int i = 0; i < jsonArray.length(); i++) {

                                    Log.d("ccc", "run: "+1);
                                    String parkName = jsonArray.getJSONObject(i).getString("parkName");
                                    String vacancy = jsonArray.getJSONObject(i).getString("plateNumber");
                                    String address = jsonArray.getJSONObject(i).getString("monetary");
                                    String rates = jsonArray.getJSONObject(i).getString("entryTime");
                                    String distance = jsonArray.getJSONObject(i).getString("outTime");

                                    park_recordBean bean = new park_recordBean();

                                    bean.setParkName(parkName);
                                    bean.setVacancy(vacancy);
                                    bean.setAddress(address);
                                    bean.setRates(rates);
                                    bean.setDistance(distance);
                                    data.add(bean);
                                }
                                mListView.setAdapter(new park_recordAdapter(data, park_record.this, isMore));//适配器

                            }else{
                                Toast.makeText(park_record.this,"没找到数据...",Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                });
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case  android.R.id.home:
                this.finish();
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}