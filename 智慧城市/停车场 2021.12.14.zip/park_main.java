package com.example.smartcity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class park_main extends AppCompatActivity {
    private List<parkBean> data = new ArrayList<>();
    private int isMore = 0;
    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.park_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("停哪儿");

        //页面列表
        mListView = (ListView) findViewById(R.id.park_lv);
        show(isMore);
        TextView show = findViewById(R.id.park_show);
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isMore++;
                show(isMore);
            }
        });

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(park_main.this, park_detail.class);
                intent.putExtra("position", id);
                startActivity(intent);

            }
        });


    }

    private void show(int isMore) {
        Network network = new Network();
        network.useSendRequestWithOkHttp("http://124.93.196.45:10001/prod-api/api/park/lot/list", new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseData = response.body().string();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        data.clear();
                        JSONArray jsonArray = network.useShowResponse(responseData);
                        mListView.setAdapter(new parkAdapter(data, park_main.this, isMore));//适配器
                        int[] arr = new int[jsonArray.length()];
                        for (int i = 0; i < jsonArray.length(); i++) {
                            try {
                                String parkName = jsonArray.getJSONObject(i).getString("parkName");
                                String vacancy = jsonArray.getJSONObject(i).getString("vacancy");
                                String address = jsonArray.getJSONObject(i).getString("address");
                                String rates = jsonArray.getJSONObject(i).getString("rates");
                                String distance = jsonArray.getJSONObject(i).getString("distance");

                                parkBean bean = new parkBean();

                                bean.setParkName(parkName);
                                bean.setVacancy(vacancy);
                                bean.setAddress(address);
                                bean.setRates(rates);
                                bean.setDistance(distance);
                                data.add(bean);


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                });
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
            case R.id.park_record:
                Intent intent = new Intent(park_main.this, park_record.class);
                startActivity(intent);

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.park_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
}