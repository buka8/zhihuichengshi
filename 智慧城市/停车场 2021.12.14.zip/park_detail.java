package com.example.smartcity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class park_detail extends AppCompatActivity {

    private ImageView mImg;
    private TextView mTextView;
    private TextView mTextView2;
    private TextView mTextView3;
    private TextView mTextView4;
    private TextView mTextView5;
    private TextView mTextView6;
    private TextView mTextView7;
    private TextView mTextView8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.park_detail);

        //返回键
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("停哪儿");

        initView();

        Intent intent = getIntent();
        Long position = intent.getLongExtra("position", 0) + 1;
        Network network = new Network();
        network.useSendRequestWithOkHttp("http://124.93.196.45:10001/prod-api/api/park/lot/" + position, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseData = response.body().string();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            JSONObject jsonObject = new JSONObject(responseData);

                            Glide.with(getApplicationContext())
                                    .load("http://124.93.196.45:10001" + jsonObject.getJSONObject("data").getString("imgUrl"))
                                    .into(mImg);

                            mTextView.setText(jsonObject.getJSONObject("data").getString("parkName"));
                            mTextView2.setText(jsonObject.getJSONObject("data").getString("vacancy"));
                            mTextView3.setText(jsonObject.getJSONObject("data").getString("address"));
                            mTextView4.setText(jsonObject.getJSONObject("data").getString("rates") + "元/小时");
                            mTextView5.setText(jsonObject.getJSONObject("data").getString("distance"));
                            mTextView6.setText(jsonObject.getJSONObject("data").getString("open"));
                            mTextView7.setText(jsonObject.getJSONObject("data").getString("priceCaps") + "元/天");
                            mTextView8.setText(jsonObject.getJSONObject("data").getString("remark"));


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                });
            }
        });

    }

    private void initView() {
        mImg = (ImageView) findViewById(R.id.park_detail_img);
        mTextView = (TextView) findViewById(R.id.park_detail_text1);
        mTextView2 = (TextView) findViewById(R.id.park_detail_text2);
        mTextView3 = (TextView) findViewById(R.id.park_detail_text3);
        mTextView4 = (TextView) findViewById(R.id.park_detail_text4);
        mTextView5 = (TextView) findViewById(R.id.park_detail_text5);
        mTextView6 = (TextView) findViewById(R.id.park_detail_text6);
        mTextView7 = (TextView) findViewById(R.id.park_detail_text7);
        mTextView8 = (TextView) findViewById(R.id.park_detail_text8);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case  android.R.id.home:
                this.finish();
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}