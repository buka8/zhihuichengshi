package com.example.smartcity;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class park_recordAdapter extends BaseAdapter {
    private List<park_recordBean> data;
    private Context mContext;
    private int isMore;

    public park_recordAdapter(List<park_recordBean> data, Context context, int isMore) {
        this.data = data;
        this.mContext = context;
        this.isMore = isMore;
    }

    @Override
    public int getCount() {
        if (isMore == 0 && data.size() < 6) {
            return data.size();
        } else if (isMore == 0) {
            return 5;
        }
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.park_record_item, parent, false);

            viewHolder.mTextView1 = (TextView) convertView.findViewById(R.id.park_item1);
            viewHolder.mTextView2 = (TextView) convertView.findViewById(R.id.park_item2);
            viewHolder.mTextView3 = (TextView) convertView.findViewById(R.id.park_item3);
            viewHolder.mTextView4 = (TextView) convertView.findViewById(R.id.park_item4);
            viewHolder.mTextView5 = (TextView) convertView.findViewById(R.id.park_item5);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }


        viewHolder.mTextView1.setText(data.get(position).getParkName());
        viewHolder.mTextView2.setText(data.get(position).getVacancy());
        viewHolder.mTextView3.setText(data.get(position).getAddress());
        viewHolder.mTextView4.setText(data.get(position).getRates());
        viewHolder.mTextView5.setText(data.get(position).getDistance());


        return convertView;
    }

    static class ViewHolder {
        TextView mTextView1;
        TextView mTextView2;
        TextView mTextView3;
        TextView mTextView4;
        TextView mTextView5;
    }
}
